﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1
{
    using System;

    class Calculator
    {
        public double Number1;
        public double Number2;

        public Calculator(double number1 = 10, double number2 = 10)
        {
            Number1 = number1;
            Number2 = number2;
        }

        public double Add()
        {
            return Number1 + Number2;
        }

        public double Subtract()
        {
            return Number1 - Number2;
        }

        public double Multiply()
        {
            return Number1 * Number2;
        }

        public string Divide()
        {
            try
            {
                double result = Number1 / Number2;
                return result.ToString();
            }
            catch (DivideByZeroException)
            {
                return "Error: Cannot divide by zero.";
            }
        }

        public string Modulo()
        {
            try
            {
                double result = Number1 % Number2;
                return result.ToString();
            }
            catch (DivideByZeroException)
            {
                return "Error: Cannot calculate modulo with zero divisor.";
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Calculator calculator = null;

            while (true)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Create a Single Object of Calculator");
                Console.WriteLine("2. Change Values of Attributes");
                Console.WriteLine("3. Add");
                Console.WriteLine("4. Subtract");
                Console.WriteLine("5. Multiply");
                Console.WriteLine("6. Divide");
                Console.WriteLine("7. Modulo");
                Console.WriteLine("8. Exit");

                Console.Write("Enter your choice (1-8): ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        calculator = new Calculator();
                        Console.WriteLine("Calculator object created with default values.");
                        break;

                    case "2":
                        if (calculator != null)
                        {
                            Console.Write("Enter the new value for Number1: ");
                            if (double.TryParse(Console.ReadLine(), out double newNumber1))
                            {
                                calculator.Number1 = newNumber1;
                            }

                            Console.Write("Enter the new value for Number2: ");
                            if (double.TryParse(Console.ReadLine(), out double newNumber2))
                            {
                                calculator.Number2 = newNumber2;
                            }

                            Console.WriteLine("Values updated.");
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created yet.");
                        }
                        break;

                    case "3":
                    case "4":
                    case "5":
                    case "6":
                    case "7":
                        if (calculator != null)
                        {
                            double result = 0;

                            switch (choice)
                            {
                                case "3":
                                    result = calculator.Add();
                                    break;

                                case "4":
                                    result = calculator.Subtract();
                                    break;

                                case "5":
                                    result = calculator.Multiply();
                                    break;

                                case "6":
                                    Console.WriteLine($"Result: {calculator.Divide()}");
                                    continue;

                                case "7":
                                    Console.WriteLine($"Result: {calculator.Modulo()}");
                                    continue;
                            }

                            Console.WriteLine($"Result: {result}");
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created yet.");
                        }
                        break;

                    case "8":
                        Console.WriteLine("Exiting the calculator program.");
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 8.");
                        break;
                }
            }
        }
    }

}
