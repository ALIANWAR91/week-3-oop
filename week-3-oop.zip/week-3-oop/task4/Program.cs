﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task4
{

    class Book
    {
        public string Title { get; }
        public string Author { get; }
        public int PublicationYear { get; }
        public double Price { get; }
        public int QuantityInStock { get; set; }

        public Book(string title, string author, int publicationYear, double price, int quantityInStock)
        {
            Title = title;
            Author = author;
            PublicationYear = publicationYear;
            Price = price;
            QuantityInStock = quantityInStock;
        }

        public string GetTitle()
        {
            return $"Title: {Title}";
        }

        public string GetAuthor()
        {
            return $"Author: {Author}";
        }

        public string GetPublicationYear()
        {
            return $"Publication Year: {PublicationYear}";
        }

        public string GetPrice()
        {
            return $"Price: ${Price}";
        }

        public void SellCopies(int numberOfCopies)
        {
            if (numberOfCopies <= QuantityInStock)
            {
                QuantityInStock -= numberOfCopies;
                Console.WriteLine($"{numberOfCopies} copies of {Title} sold successfully.");
            }
            else
            {
                Console.WriteLine($"Error: Not enough copies of {Title} in stock.");
            }
        }

        public void Restock(int additionalCopies)
        {
            QuantityInStock += additionalCopies;
            Console.WriteLine($"{additionalCopies} copies of {Title} added to the stock.");
        }

        public string BookDetails()
        {
            return $"{GetTitle()}, {GetAuthor()}, {GetPublicationYear()}, {GetPrice()}, Stock: {QuantityInStock}";
        }
    }

    class Program
    {
        static void Main()
        {
            List<Book> bookList = new List<Book>();

            while (true)
            {
                Console.WriteLine("\nMenu Options:");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. View All the Books information");
                Console.WriteLine("3. Get the Author details of a specific book");
                Console.WriteLine("4. Sell Copies of a Specific Book");
                Console.WriteLine("5. Restock a Specific Book");
                Console.WriteLine("6. See the count of the Books present in your bookList");
                Console.WriteLine("7. Exit");

                Console.Write("Enter your choice (1-7): ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Enter the title of the book: ");
                        string title = Console.ReadLine();
                        Console.Write("Enter the author of the book: ");
                        string author = Console.ReadLine();
                        Console.Write("Enter the publication year of the book: ");
                        int publicationYear = int.Parse(Console.ReadLine());
                        Console.Write("Enter the price of the book: $");
                        double price = double.Parse(Console.ReadLine());
                        Console.Write("Enter the quantity in stock: ");
                        int quantityInStock = int.Parse(Console.ReadLine());

                        Book newBook = new Book(title, author, publicationYear, price, quantityInStock);
                        bookList.Add(newBook);
                        Console.WriteLine($"Book '{title}' added successfully.");
                        break;

                    case "2":
                        foreach (Book book in bookList)
                        {
                            Console.WriteLine(book.BookDetails());
                        }
                        break;

                    case "3":
                        Console.Write("Enter the title of the book: ");
                        string searchTitle = Console.ReadLine();
                        Book foundBook = bookList.Find(book => book.Title == searchTitle);
                        if (foundBook != null)
                        {
                            Console.WriteLine(foundBook.GetAuthor());
                        }
                        else
                        {
                            Console.WriteLine($"Book with title '{searchTitle}' not found.");
                        }
                        break;

                    case "4":
                        Console.Write("Enter the title of the book: ");
                        string sellTitle = Console.ReadLine();
                        Book sellBook = bookList.Find(book => book.Title == sellTitle);
                        if (sellBook != null)
                        {
                            Console.Write($"Enter the number of copies of '{sellTitle}' to sell: ");
                            int copiesToSell = int.Parse(Console.ReadLine());
                            sellBook.SellCopies(copiesToSell);
                        }
                        else
                        {
                            Console.WriteLine($"Book with title '{sellTitle}' not found.");
                        }
                        break;

                    case "5":
                        Console.Write("Enter the title of the book: ");
                        string restockTitle = Console.ReadLine();
                        Book restockBook = bookList.Find(book => book.Title == restockTitle);
                        if (restockBook != null)
                        {
                            Console.Write($"Enter the number of copies of '{restockTitle}' to restock: ");
                            int copiesToRestock = int.Parse(Console.ReadLine());
                            restockBook.Restock(copiesToRestock);
                        }
                        else
                        {
                            Console.WriteLine($"Book with title '{restockTitle}' not found.");
                        }
                        break;

                    case "6":
                        Console.WriteLine($"Total books in the list: {bookList.Count}");
                        break;

                    case "7":
                        Console.WriteLine("Exiting the program.");
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 7.");
                        break;
                }
            }
        }
    }
}
