﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3
{
    class Shiritori
    {
        private List<string> words;
        private bool game_over;

        public Shiritori()
        {
            words = new List<string>();
            game_over = false;
        }

        public object Play(string word)
        {
            if (game_over)
                return "game over";

            if (words.Count > 0)
            {
                if (word.ToLower()[0] == words[words.Count - 1].ToLower()[words[words.Count - 1].Length - 1]
                    && !words.Contains(word.ToLower()))
                {
                    words.Add(word.ToLower());
                    return words;
                }
                else
                {
                    game_over = true;
                    return "game over";
                }
            }
            else
            {
                words.Add(word.ToLower());
                return words;
            }
        }
        public string Restart()
        {
            words.Clear();
            game_over = false;
            return "game restarted";
        }
        public List<string> Words
        {
            get { return words; }
        }
    }

}
