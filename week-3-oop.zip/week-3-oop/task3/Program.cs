﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3
{
    
    class Program
    {
        static void Main()
        {
            Shiritori shiritoriGame = new Shiritori();
            Console.WriteLine(shiritoriGame.Play("apple")); 
            Console.WriteLine(shiritoriGame.Play("elephant"));
            Console.WriteLine(shiritoriGame.Play("tiger"));  
            Console.WriteLine(string.Join(", ", shiritoriGame.Words)); 
            Console.WriteLine(shiritoriGame.Restart());  
            Console.WriteLine(shiritoriGame.Play("tiger"));  
            Console.WriteLine(shiritoriGame.Play("rabbit")); 
        }
    }
}
