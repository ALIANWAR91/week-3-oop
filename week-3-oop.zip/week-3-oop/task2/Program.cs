﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    class Calculator
    {
        public double Number1 { get; set; }
        public double Number2 { get; set; }

        public Calculator(double number1 = 10, double number2 = 10)
        {
            Number1 = number1;
            Number2 = number2;
        }

        // Basic arithmetic operations
        public double Add()
        {
            return Number1 + Number2;
        }

        public double Subtract()
        {
            return Number1 - Number2;
        }

        public double Multiply()
        {
            return Number1 * Number2;
        }

        public string Divide()
        {
            try
            {
                double result = Number1 / Number2;
                return result.ToString();
            }
            catch (DivideByZeroException)
            {
                return "Error: Cannot divide by zero.";
            }
        }

        public string Modulo()
        {
            try
            {
                double result = Number1 % Number2;
                return result.ToString();
            }
            catch (DivideByZeroException)
            {
                return "Error: Cannot calculate modulo with zero divisor.";
            }
        }

        public double Sqrt(double value)
        {
            if (value >= 0)
            {
                return Math.Sqrt(value);
            }
            else
            {
                return double.NaN; 
            }
        }

        public double Exp(double exponent)
        {
            return Math.Exp(exponent);
        }

        public double Log(double value)
        {
            if (value > 0)
            {
                return Math.Log(value);
            }
            else
            {
                return double.NaN;
            }
        }

        public double Sin(double angleInDegrees)
        {
            return Math.Sin(Math.PI * angleInDegrees / 180.0);
        }

        public double Cos(double angleInDegrees)
        {
            return Math.Cos(Math.PI * angleInDegrees / 180.0);
        }

        public double Tan(double angleInDegrees)
        {
            return Math.Tan(Math.PI * angleInDegrees / 180.0);
        }
    }

    class Program
    {
        static void Main()
        {
            Calculator calculator = null;

            while (true)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Create a Single Object of Calculator");
                Console.WriteLine("2. Change Values of Attributes");
                Console.WriteLine("3. Add");
                Console.WriteLine("4. Subtract");
                Console.WriteLine("5. Multiply");
                Console.WriteLine("6. Divide");
                Console.WriteLine("7. Modulo");
                Console.WriteLine("8. Square Root");
                Console.WriteLine("9. Exponential Function");
                Console.WriteLine("10. Logarithm");
                Console.WriteLine("11. Sine");
                Console.WriteLine("12. Cosine");
                Console.WriteLine("13. Tangent");
                Console.WriteLine("14. Exit");

                Console.Write("Enter your choice (1-14): ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    // Existing functionalities
                    case "1":
                        Console.Write("Enter the initial value for Number1: ");
                        double initialNumber1 = double.Parse(Console.ReadLine());

                        Console.Write("Enter the initial value for Number2: ");
                        double initialNumber2 = double.Parse(Console.ReadLine());

                        calculator = new Calculator(initialNumber1, initialNumber2);
                        Console.WriteLine("Calculator object created with specified values.");
                        break;

                    case "2":
                        if (calculator != null)
                        {
                            Console.Write("Enter the new value for Number1: ");
                            if (double.TryParse(Console.ReadLine(), out double newNumber1))
                            {
                                calculator.Number1 = newNumber1;
                            }

                            Console.Write("Enter the new value for Number2: ");
                            if (double.TryParse(Console.ReadLine(), out double newNumber2))
                            {
                                calculator.Number2 = newNumber2;
                            }

                            Console.WriteLine("Values updated.");
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created yet.");
                        }
                        break;

                    case "3":
                    case "4":
                    case "5":
                    case "6":
                    case "7":
                        PerformBasicOperation(calculator, choice);
                        break;
                    case "8":
                    case "9":
                    case "10":
                    case "11":
                    case "12":
                    case "13":
                        PerformScientificOperation(calculator, choice);
                        break;

                    case "14":
                        Console.WriteLine("Exiting the calculator program.");
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 14.");
                        break;
                }
            }
        }

        static void PerformBasicOperation(Calculator calculator, string choice)
        {
            if (calculator != null)
            {
                double result = 0;

                switch (choice)
                {
                    case "3":
                        result = calculator.Add();
                        break;

                    case "4":
                        result = calculator.Subtract();
                        break;

                    case "5":
                        result = calculator.Multiply();
                        break;

                    case "6":
                        Console.WriteLine($"Result: {calculator.Divide()}");
                        return;

                    case "7":
                        Console.WriteLine($"Result: {calculator.Modulo()}");
                        return;
                }

                Console.WriteLine($"Result: {result}");
            }
            else
            {
                Console.WriteLine("Error: Calculator object not created yet.");
            }
        }

        static void PerformScientificOperation(Calculator calculator, string choice)
        {
            if (calculator != null)
            {
                double result = 0;

                switch (choice)
                {
                    case "8":
                        Console.Write("Enter the value for the square root: ");
                        if (double.TryParse(Console.ReadLine(), out double sqrtValue))
                        {
                            result = calculator.Sqrt(sqrtValue);
                        }
                        else
                        {
                            Console.WriteLine("Invalid input for square root operation.");
                            return;
                        }
                        break;

                    case "9":
                        Console.Write("Enter the exponent for the exponential function: ");
                        if (double.TryParse(Console.ReadLine(), out double expExponent))
                        {
                            result = calculator.Exp(expExponent);
                        }
                        else
                        {
                            Console.WriteLine("Invalid input for exponential function.");
                            return;
                        }
                        break;

                    case "10":
                        Console.Write("Enter the value for the logarithm: ");
                        if (double.TryParse(Console.ReadLine(), out double logValue))
                        {
                            result = calculator.Log(logValue);
                        }
                        else
                        {
                            Console.WriteLine("Invalid input for logarithm operation.");
                            return;
                        }
                        break;

                    case "11":
                    case "12":
                    case "13":
                        Console.Write("Enter the angle in degrees: ");
                        if (double.TryParse(Console.ReadLine(), out double trigAngle))
                        {
                            switch (choice)
                            {
                                case "11":
                                    result = calculator.Sin(trigAngle);
                                    break;

                                case "12":
                                    result = calculator.Cos(trigAngle);
                                    break;

                                case "13":
                                    result = calculator.Tan(trigAngle);
                                    break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid input for trigonometric operation.");
                            return;
                        }
                        break;
                }

                Console.WriteLine($"Result: {result}");
            }
            else
            {
                Console.WriteLine("Error: Calculator object not created yet.");
            }
        }
    }

}
